var app      = getApp();

var pageData = {
  data: {"text1":{"type":"text","style":"background-image:url(http:\/\/img.weiye.me\/zcimgdir\/thumb\/t_15135728715a374a078b20e.jpg);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(102, 102, 102);font-size:32.8125rpx;height:44.53125rpx;line-height:44.53125rpx;margin-left:auto;margin-top:0;opacity:1;text-align:left;","content":"                            \u5386\u5e74\u4e13\u4e1a\u8bbe\u7f6e\n \n1952\u5e74\uff5e1958\u5e74 \n \n\u6709\u7ebf\u7535\u5de5\u7a0b\u7cfb\uff1a\u7535\u62a5\u7535\u8bdd\u901a\u4fe1\u3001\u901a\u4fe1\u81ea\u52a8\u63a7\u5236\uff0859\uff09\u3001\u6709\u7ebf\u5236\u9020\uff0859\uff09 \n \n\u65e0\u7ebf\u7535\u5de5\u7a0b\u7cfb\uff1a\u65e0\u7ebf\u7535\u901a\u4fe1\u53ca\u5e7f\u64ad\u3001\u7535\u5b50\u7535\u8def\uff0858\u300159\uff09\u3001\u65e0\u7ebf\u5236\u9020\uff0859\uff09\u3001\u5fae\u6ce2\u901a\u4fe1\uff0859\uff09 \n \n1960\u5e74 \n \n\u6709\u7ebf\u7535\u5de5\u7a0b\u7cfb\uff1a\u7535\u62a5\u7535\u8bdd\u901a\u4fe1\u3001\u6709\u7ebf\u5236\u9020\u3001\u90ae\u673a\u3001\u957f\u9014\u7535\u8bdd\u4e13\u4fee\u79d1\u3001\u7ebf\u8def\u4e13\u4fee\u79d1\u3001\u7535\u62a5\u4e13\u4fee\u79d1 \n \n\u65e0\u7ebf\u7535\u5de5\u7a0b\u7cfb\uff1a\u65e0\u7ebf\u7535\u901a\u4fe1\u53ca\u5e7f\u64ad\u3001\u65e0\u7ebf\u5236\u9020\u3001\u65e0\u7ebf\u7269\u7406\u3001\u65e0\u7ebf\u7535\u901a\u4fe1\u53ca\u5e7f\u64ad\u4e13\u4fee\u79d1 \n \n1961\u5e74\uff5e1965\u5e74 \n \n\u6709\u7ebf\u7535\u5de5\u7a0b\u7cfb\uff1a\u7535\u62a5\u7535\u8bdd\u901a\u4fe1\u3001\u901a\u4fe1\u81ea\u52a8\u63a7\u5236\uff0861\u300162\uff09\u3001\u6709\u7ebf\u5236\u9020\uff0861\uff5e63\uff09\u3001\u6709\u7ebf\u7535\u8bbe\u5907\uff0864\u300165\uff09 \n \n\u65e0\u7ebf\u7535\u5de5\u7a0b\u7cfb\uff1a\u65e0\u7ebf\u7535\u901a\u4fe1\u53ca\u5e7f\u64ad\u3001\u65e0\u7ebf\u7269\u7406\u3001\u65e0\u7ebf\u5236\u9020\uff0861\uff5e63\uff09\u3001\u65e0\u7ebf\u7535\u6280\u672f\uff0864\u300165\uff09 \n \n1966\u5e74\uff5e1970\u5e74\u505c\u62db \n \n1971\u5e74\uff5e1976\u5e74 \n \n\u7535\u4fe1\u5de5\u7a0b\u7cfb\uff1a\u6570\u5b57\u901a\u4fe1\uff0871\uff5e74\u300176\uff09\u3001\u8f7d\u6ce2\u901a\u4fe1\u3001\u957f\u8bdd\u81ea\u52a8\u4ea4\u6362\uff0872\uff09\u3001\u7535\u5b50\u5668\u4ef6\uff0872\u300173\u300176\uff09\u3001\u7535\u5b50\u4ea4\u6362\uff0873\uff5e76\uff09\u3001\u901a\u4fe1\u7535\u529b\uff0876\uff09 \n \n\u65e0\u7ebf\u7535\u5de5\u7a0b\u7cfb\uff1a\u5fae\u6ce2\u901a\u4fe1\u3001\u65e0\u7ebf\u901a\u4fe1\uff0873\uff09\u3001\u65e0\u7ebf\u7535\u6280\u672f\uff0874\uff5e76\uff09\u3001\u7535\u89c6\uff0874\uff5e76\uff09 \n \n1977\u5e74\uff5e1985\u5e74 \n \n\u7535\u4fe1\u5de5\u7a0b\u7cfb\uff1a\u6570\u5b57\u901a\u4fe1\uff0877\uff5e79\uff09\u3001\u8f7d\u6ce2\u901a\u4fe1\uff0877\uff5e79\uff09\u3001\u8ba1\u7b97\u673a\u901a\u4fe1\uff0877\uff5e84\uff09\u3001\u7535\u4fe1\u5de5\u7a0b\uff0880\uff5e84\uff09\u3001\u901a\u4fe1\u5de5\u7a0b\uff0885\uff09 \n \n\u65e0\u7ebf\u7535\u5de5\u7a0b\u7cfb\uff1a\u5fae\u6ce2\u901a\u4fe1\uff0877\uff5e80\u300182\uff09\u3001\u65e0\u7ebf\u7535\u6280\u672f\uff0877\uff5e80\uff09\u3001\u7535\u89c6\uff0877\u300178\u300180\uff09\u3001\u65e0\u7ebf\u7535\u5de5\u7a0b\uff0881\u300183\uff09\u3001\u7535\u78c1\u573a\u4e0e\u5fae\u6ce2\u6280\u672f\uff0885\uff09\u3001\u65e0\u7ebf\u7535\u901a\u4fe1\uff0885\uff09\u3001\u56fe\u50cf\u4f20\u8f93\u4e0e\u5904\u7406\uff0885\uff09\u3001\u65e0\u7ebf\u7535\u5de5\u7a0b\uff0880\u591c\u5927\uff09 \n \n1986\u5e74\uff5e1996\u5e74 \n \n\u7535\u4fe1\u5de5\u7a0b\u7cfb\uff1a\u901a\u4fe1\u5de5\u7a0b\u3001\u5149\u7f06\u901a\u4fe1\uff0891\u300192\u4e13\u79d1\uff09\u3001\u901a\u4fe1\u5de5\u7a0b\uff0893\u4e13\u79d1\uff09\u3001\u5149\u7ea4\u901a\u4fe1\uff0893\uff5e95\u4e13\u79d1\uff09\u3001\u7a0b\u63a7\u4ea4\u6362\uff0891\u300192\u300194\u4e13\u79d1\uff09\u300196\u65b0\u7586\u73ed \n \n\u65e0\u7ebf\u7535\u5de5\u7a0b\u7cfb\uff1a\u7535\u78c1\u573a\u4e0e\u5fae\u6ce2\u6280\u672f\u3001\u65e0\u7ebf\u7535\u901a\u4fe1\uff0886\uff5e95\uff09\u3001\u56fe\u50cf\u4f20\u8f93\u4e0e\u5904\u7406\uff0886\uff5e95\uff09\u3001\u65e0\u7ebf\u7535\u6280\u672f\uff0887\uff5e92\u300194\uff5e96\u591c\u5927\uff09\u3001\u536b\u661f\u901a\u4fe1\uff0891\u4e13\u79d1\uff09\u3001\u6570\u5b57\u5fae\u6ce2\uff0892\u4e13\u79d1\uff09\u3001\u79fb\u52a8\u901a\u4fe1\uff0893\uff5e96\u4e13\u79d1\uff09 \n \n\u4fe1\u606f\u5de5\u7a0b\u7cfb\uff1a\u4fe1\u606f\u5de5\u7a0b\u3001\u5e94\u7528\u6570\u5b66\uff0886\uff5e93\uff09\u3001\u4fe1\u606f\u79d1\u5b66\uff0894\uff09\u3001\u81ea\u52a8\u5316\uff0895\uff5e96\uff09 \n \n1997\u5e74\uff5e1999\u5e74 \n \n\u7535\u4fe1\u5de5\u7a0b\u5b66\u9662\uff1a\u901a\u4fe1\u5de5\u7a0b\u3001\u7535\u5b50\u4fe1\u606f\u5de5\u7a0b\u3001\u901a\u4fe1\u5de5\u7a0b\uff0897\uff5e99\u591c\u5927\uff09 \n \n\u4fe1\u606f\u5de5\u7a0b\u7cfb\uff1a\u4fe1\u606f\u5de5\u7a0b\u3001\u4fe1\u606f\u79d1\u5b66\u3001\u81ea\u52a8\u5316 \n \n2000\u5e74\uff5e2008\u5e74 \n \n\u7535\u4fe1\u5de5\u7a0b\u5b66\u9662\uff1a\u901a\u4fe1\u5de5\u7a0b\u3001\u7535\u5b50\u4fe1\u606f\u5de5\u7a0b \n \n\u4fe1\u606f\u5de5\u7a0b\u5b66\u9662\uff1a\u4fe1\u606f\u5de5\u7a0b\u3001\u4fe1\u606f\u4e0e\u8ba1\u7b97\u79d1\u5b66\u3001\u81ea\u52a8\u5316\u3001\u4fe1\u606f\u5b89\u5168\uff0802\uff5e08\uff09\u3001\u6570\u5b57\u5a92\u4f53\u827a\u672f\uff0804\uff5e08\uff09\u3001\u667a\u80fd\u79d1\u5b66\u4e0e\u6280\u672f\uff0806\uff5e08\uff09 \n \n2009\u5e74\uff5e2011\u5e74 \n \n\u4fe1\u606f\u4e0e\u901a\u4fe1\u5de5\u7a0b\u5b66\u9662\uff1a\u901a\u4fe1\u5de5\u7a0b\u3001\u4fe1\u606f\u5de5\u7a0b\u3001\u7535\u5b50\u4fe1\u606f\u5de5\u7a0b\u3001\u6570\u5b57\u5a92\u4f53\u6280\u672f \n \n2012\u5e74\u81f3\u4eca \n \n\u4fe1\u606f\u4e0e\u901a\u4fe1\u5de5\u7a0b\u5b66\u9662\uff1a\u901a\u4fe1\u5de5\u7a0b\u3001\u4fe1\u606f\u5de5\u7a0b\u3001\u7535\u5b50\u4fe1\u606f\u5de5\u7a0b \n\n","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0"},"animations":[],"page_form":"","compId":"text1","parentCompid":"text1","markColor":"","mode":0},"text2":{"type":"text","style":"background-image:url(http:\/\/img.weiye.me\/zcimgdir\/thumb\/t_15135973165a37a98487757.jpg);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(102, 102, 102);font-size:32.8125rpx;height:44.53125rpx;line-height:44.53125rpx;margin-left:auto;margin-top:0;opacity:1;text-align:left;","content":"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0"},"animations":[],"page_form":"","compId":"text2","parentCompid":"text2","markColor":"","mode":0},"text3":{"type":"text","style":"background-image:url(http:\/\/img.weiye.me\/zcimgdir\/thumb\/t_15135973525a37a9a872da4.jpg);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(102, 102, 102);font-size:32.8125rpx;height:44.53125rpx;line-height:44.53125rpx;margin-left:auto;margin-top:0;opacity:1;text-align:left;","content":"\n\n\n\n\n\n\n\n\n\n\n","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0"},"animations":[],"page_form":"","compId":"text3","parentCompid":"text3","markColor":"","mode":0},"has_tabbar":0,"page_hidden":true,"page_form":"","top_nav":{"navigationBarBackgroundColor":"#000000","navigationBarTextStyle":"white","navigationBarTitleText":"\u65b0\u9875\u9762"}},
    need_login: false,
    page_router: 'page10007',
    page_form: 'none',
      list_compids_params: [],
      user_center_compids_params: [],
      goods_compids_params: [],
  prevPage:0,
      tostoreComps: [],
      carouselGroupidsParams: [],
      relobj_auto: [],
      bbsCompIds: [],
      dynamicVesselComps: [],
      communityComps: [],
      franchiseeComps: [],
      cityLocationComps: [],
      seckillOnLoadCompidParam: [],
      dynamicClassifyGroupidsParams: [],
      videoListComps: [],
      videoProjectComps: [],
      returnToVersionFlag: true,
  requesting: false,
  requestNum: 1,
  modelChoose: [],
  modelChooseId: '',
  modelChooseName: [],
  onLoad: function (e) {
    app.onPageLoad(e);
  },
  dataInitial: function () {
    app.pageDataInitial();
  },
  onShareAppMessage: function (e) {
    return app.onPageShareAppMessage(e);
  },
  onShow: function () {
    app.onPageShow();
  },
  reachBottomFuc: [],
  onReachBottom: function () {
    app.onPageReachBottom( this.reachBottomFuc );
  },
  onUnload: function () {
    app.onPageUnload();
  },
  tapPrevewPictureHandler: function (e) {
    app.tapPrevewPictureHandler(e);
  },
  suspensionBottom: function () {
    app.suspensionBottom();
  },
  pageScrollFunc: function (e) {
    app.pageScrollFunc(e);
  },
  dynamicVesselScrollFunc: function (e) {
    app.dynamicVesselScrollFunc(e);
  },
  goodsScrollFunc: function (e) {
    app.goodsScrollFunc(e);
  },
  takeoutStyleScrollFunc: function(e){
    app.takeoutStyleScrollFunc(e);
  },
  franchiseeScrollFunc: function (e) {
    app.franchiseeScrollFunc(e);
  },
  seckillScrollFunc: function (e) {
    app.seckillScrollFunc(e);
  },
  videoScrollFunc: function (e) {
    app.videoScrollFunc(e);
  },
  carouselVideoClose: function(e) {
    app.carouselVideoClose(e);
  },
  changeCount: function (e) {
    app.changeCount(e);
  },
  inputChange: function (e) {
    app.inputChange(e);
  },
  bindDateChange: function (e) {
    app.bindDateChange(e);
  },
  bindTimeChange: function (e) {
    app.bindTimeChange(e);
  },
  bindSelectChange: function (e) {
    app.bindSelectChange(e);
  },
  bindScoreChange: function (e) {
    app.bindScoreChange(e);
  },
  submitForm: function (e) {
    app.submitForm(e);
  },
  udpateVideoSrc: function (e) {
    app.udpateVideoSrc(e);
  },
  tapMapDetail: function (e) {
    app.tapMapDetail(e);
  },
  uploadFormImg: function (e) {
    app.uploadFormImg(e);
  },
  deleteUploadImg: function (e) {
    app.deleteUploadImg(e);
  },
  listVesselTurnToPage: function (e) {
    app.listVesselTurnToPage(e);
  },
  dynamicVesselTurnToPage: function (e) {
    app.dynamicVesselTurnToPage(e);
  },
  userCenterTurnToPage: function (e) {
    app.userCenterTurnToPage(e);
  },
  turnToGoodsDetail: function (e) {
    app.turnToGoodsDetail(e);
  },
  turnToFranchiseeDetail: function (e) {
    app.turnToFranchiseeDetail(e);
  },
  turnToSeckillDetail: function (e) {
    app.turnToSeckillDetail(e);
  },
  sortListFunc: function (e) {
    app.sortListFunc(e);
  },
  bbsInputComment: function (e) {
    app.bbsInputComment(e);
  },
  bbsInputReply: function (e) {
    app.bbsInputReply(e);
  },
  uploadBbsCommentImage: function (e) {
    app.uploadBbsCommentImage(e);
  },
  uploadBbsReplyImage: function (e) {
    app.uploadBbsReplyImage(e);
  },
  deleteCommentImage: function (e) {
    app.deleteCommentImage(e);
  },
  deleteReplyImage: function (e) {
    app.deleteReplyImage(e);
  },
  bbsPublishComment: function (e) {
    app.bbsPublishComment(e);
  },
  clickBbsReplyBtn: function (e) {
    app.clickBbsReplyBtn(e);
  },
  bbsPublishReply: function (e) {
    app.bbsPublishReply(e);
  },
  searchList: function (e) {
    app.searchList(e);
  },
  selectLocal: function (e) {
    app.selectLocal(e);
  },
  cancelCity: function (e) {
    app.cancelCity(e);
  },
  bindCityChange: function (e) {
    app.bindCityChange(e);
  },
  submitCity: function (e) {
    app.submitCity(e);
  },
  openTakeoutLocation: function (e) {
    app.openTakeoutLocation(e);
  },
  callTakeout: function (e) {
    app.callTakeout(e);
  },
  getMoreAssess: function (e) {
    app.getMoreAssess(e);
  },
  changeEvaluate: function (e) {
    app.changeEvaluate(e)
  },
  deleteAllCarts: function (e) {
    app.deleteAllCarts(e);
  },
  clickCategory: function (e) {
    app.clickCategory(e);
  },
  goodsListMinus: function (e) {
    app.goodsListMinus(e);
  },
  goodsListPlus: function (e) {
    app.goodsListPlus(e);
  },
  cartListMinus: function (e) {
    app.cartListMinus(e);
  },
  cartListPlus: function (e) {
    app.cartListPlus(e);
  },
  changeAssessType: function (e) {
    app.changeAssessType(e);
  },
  showShoppingCartPop: function (e) {
    app.showShoppingCartPop(e);
  },
  hideShoppingCart: function (e) {
    app.hideShoppingCart(e);
  },
  showGoodsDetail: function (e) {
    app.showGoodsDetail(e);
  },
  hideDetailPop: function (e) {
    app.hideDetailPop(e);
  },
  hideModelPop: function (e) {
    app.hideModelPop(e);
  },
  chooseModel: function (e) {
    app.chooseModel(e);
  },
  sureChooseModel: function (e) {
    app.sureChooseModel(e);
  },
  clickChooseComplete: function (e) {
    app.clickChooseComplete(e);
  },
  reLocalAddress: function(e){
    app.reLocalAddress(e);
  },
  tapGoodsTradeHandler: function (e) {
    app.tapGoodsTradeHandler(e);
  },
  tapVideoHandler: function(e){
    app.tapVideoHandler(e);
  },
  tapVideoPlayHandler: function(e){
    app.tapVideoPlayHandler(e);  
  },
  tapVideoHandler: function(e){
    app.tapVideoHandler(e);
  },
  tapInnerLinkHandler: function (e) {
    app.tapInnerLinkHandler(e);
  },
  tapPhoneCallHandler: function (e) {
    app.tapPhoneCallHandler(e);
  },
  tapRefreshListHandler: function (e) {
    app.tapRefreshListHandler(e);
  },
  tapGetCouponHandler: function (e) {
    app.tapGetCouponHandler(e);
  },
  tapCommunityHandler: function (e) {
    app.tapCommunityHandler(e);
  },
  tapPageShareHandler:function(e) {
    app.tapPageShareHandler(e);
  },
  turnToCommunityPage: function (e) {
    app.turnToCommunityPage(e);
  },
  tapToFranchiseeHandler: function (e) {
    app.tapToFranchiseeHandler(e);
  },
  tapToTransferPageHandler: function () {
    app.tapToTransferPageHandler();
  },
  tapToSeckillHandler: function (e) {
    app.tapToSeckillHandler(e);
  },
  tapToPromotionHandler: function () {
    app.tapToPromotionHandler();
  },
  tapToCouponReceiveListHandler: function () {
    app.tapToCouponReceiveListHandler();
  },
  tapToRechargeHandler: function () {
    app.tapToRechargeHandler();
  },
  tapToXcx: function (e) {
    app.tapToXcx(e);
  },
  tapFranchiseeLocation: function (e) {
    app.tapFranchiseeLocation(e);
  },
  showAddShoppingcart: function (e) {
    app.showAddShoppingcart(e);
  },
  hideAddShoppingcart: function () {
    app.hideAddShoppingcart();
  },
  selectGoodsSubModel: function (e) {
    app.selectGoodsSubModel(e);
  },
  resetSelectCountPrice: function () {
    app.resetSelectCountPrice();
  },
  // 电商
  clickGoodsMinusButton: function (e) {
    app.clickGoodsMinusButton();
  },
  clickGoodsPlusButton: function (e) {
    app.clickGoodsPlusButton();
  },
  sureAddToShoppingCart: function () {
    app.sureAddToShoppingCart();
  },
  sureAddToBuyNow: function () {
    app.sureAddToBuyNow();
  },
  clickTostoreMinusButton: function (e) {
    app.clickTostoreMinusButton(e);
  },
  clickTostorePlusButton: function (e) {
    app.clickTostorePlusButton(e);
  },
  readyToPay: function () {
    app.readyToTostorePay();
  },
  getValidateTostore: function () {
    app.getValidateTostore();
  },
  goToShoppingCart: function () {
    app.goToShoppingCart();
  },
  getCartList: function () {
    app.getTostoreCartList();
  },
  stopPropagation: function () {
  },
  turnToSearchPage:function (e) {
    app.turnToSearchPage(e);
  },
  previewImage: function (e) {
    var dataset = e.currentTarget.dataset;
    app.previewImage({
      current : dataset.src,
      urls: dataset.previewImgarr,
    });
  },
  scrollPageTop: function () {
    app.pageScrollTo(0);
  },
  suspensionTurnToPage: function (e) {
    app.suspensionTurnToPage(e);
  },
   tapToLuckyWheel: function (e) {
    app.tapToLuckyWheel(e);
  },
  tapToGoldenEggs: function (e) {
    app.tapToGoldenEggs(e);
  },
  tapToScratchCard: function (e) {
    app.tapToScratchCard(e);
  },
  tapToLuckyWheel: function (e) {
    app.tapToLuckyWheel(e);
  },
  keywordList:{},
  bindSearchTextChange: function (e) {
    this.keywordList[e.currentTarget.dataset.compid] = e.detail.value;
  },
  // 文字组件跳到地图
  textToMap: function(e) {
    app.textToMap(e);
  },
  tapDynamicClassifyFunc: function(e){
    app.tapDynamicClassifyFunc(e);
  },
  // 跳转到视频详情
  turnToVideoDetail : function(e) {
    app.turnToVideoDetail(e);
  },
  // 单个视频组件播放视频
  startPlayVideo : function(e) {
    app.startPlayVideo(e);
  },
  // 视频播放报错
  videoError: function(e) {
    app.showModal({
      content: e.detail.errMsg
    });
  }
};
Page(pageData);
