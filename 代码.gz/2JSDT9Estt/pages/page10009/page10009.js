var app      = getApp();

var pageData = {
  data: {"text1":{"type":"text","style":"background-image:url(http:\/\/img.weiye.me\/zcimgdir\/thumb\/t_15135729155a374a3306d60.jpg);border-color:rgb(34, 34, 34);border-style:none;border-width:4.6875rpx;color:rgb(102, 102, 102);font-size:42.1875rpx;height:44.53125rpx;line-height:44.53125rpx;margin-left:auto;margin-top:0;opacity:1;text-align:left;","content":"                       \u5b66\u6821\u8363\u8a89\n       \u5b66\u9662\u62e5\u6709\u201c\u4fe1\u606f\u5185\u5bb9\u5b89\u5168\u6280\u672f\u201d\u56fd\u5bb6\u5de5\u7a0b\u5b9e\u9a8c\u5ba4\u3001\u201c\u79fb\u52a8\u4e92\u8054\u7f51\u5b89\u5168\u6280\u672f\u201d\u56fd\u5bb6\u5de5\u7a0b\u5b9e\u9a8c\u5ba4\u3001\u201c\u6cdb\u7f51\u65e0\u7ebf\u901a\u4fe1\u201d\u6559\u80b2\u90e8\u91cd\u70b9\u5b9e\u9a8c\u5ba4\u3001\u201c\u5148\u8fdb\u4fe1\u606f\u7f51\u7edc\u5317\u4eac\u5b9e\u9a8c\u5ba4\u201d\u3001\u201c\u9ad8\u7b49\u667a\u80fd\u4e0e\u7f51\u7edc\u670d\u52a1\u201d\u548c\u201c\u65e0\u7ebf\u7f51\u7edc\u878d\u5408\u201d111\u521b\u65b0\u5f15\u667a\u57fa\u5730\u3001\u201c\u7f51\u7edc\u4f53\u7cfb\u6784\u5efa\u4e0e\u878d\u5408\u201d\u548c\u201c\u7f51\u7edc\u7cfb\u7edf\u4e0e\u7f51\u7edc\u6587\u5316\u201d\u5317\u4eac\u5e02\u91cd\u70b9\u5b9e\u9a8c\u5ba4\uff0c\u8fd8\u62e5\u6709\u201c\u56fd\u5bb6\u57fa\u91d1\u59d4\u521b\u65b0\u7fa4\u4f53\u201d\u548c\u201c\u6559\u80b2\u90e8\u521b\u65b0\u56e2\u961f\u201d\u3002\u5b66\u9662\u627f\u62c5\u548c\u5b8c\u6210\u4e86\u5927\u91cf\u7684\u56fd\u5bb6\u91cd\u5927\u79d1\u6280\u4e13\u9879\u3001\u56fd\u5bb6973\u8ba1\u5212\u3001\u56fd\u5bb6863\u8ba1\u5212\u3001\u56fd\u5bb6\u79d1\u6280\u652f\u6491\u8ba1\u5212\u3001\u56fd\u5bb6\u81ea\u7136\u79d1\u5b66\u57fa\u91d1\u4ee5\u53ca\u7701\u90e8\u7ea7\u7684\u91cd\u5927\u91cd\u70b9\u79d1\u7814\u9879\u76ee\uff0c\u4e5f\u627f\u62c5\u548c\u5b8c\u6210\u4e86\u5927\u91cf\u7684\u56fd\u9645\u5408\u4f5c\u548c\u4f01\u4e1a\u5408\u4f5c\u79d1\u7814\u9879\u76ee\u3002\u83b7\u5f97\u8bb8\u591a\u9879\u56fd\u5bb6\u6280\u672f\u53d1\u660e\u5956\u3001\u56fd\u5bb6\u79d1\u6280\u8fdb\u6b65\u5956\u3001\u7701\u90e8\u7ea7\u81ea\u7136\u79d1\u5b66\u5956\u3001\u7701\u90e8\u7ea7\u79d1\u6280\u8fdb\u6b65\u5956\u3001\u4e2d\u56fd\u4eba\u6c11\u89e3\u653e\u519b\u79d1\u5b66\u6280\u672f\u8fdb\u6b65\u5956\u7b49\u91cd\u5927\u5956\u52b1\u3002 \n \n\u5b66\u9662\u975e\u5e38\u91cd\u89c6\u5bf9\u5916\u4ea4\u6d41\u4e0e\u5408\u4f5c\uff0c\u901a\u8fc7\u5efa\u7acb\u8054\u5408\u5b9e\u9a8c\u5ba4\u3001\u9879\u76ee\u5408\u4f5c\u3001\u4eba\u5458\u4ea4\u6d41\u53ca\u4e13\u5bb6\u4e92\u8bbf\uff0c\u5bf9\u79d1\u5b66\u7814\u7a76\u3001\u5b66\u672f\u4ea4\u6d41\u548c\u4eba\u624d\u57f9\u517b\u90fd\u8d77\u5230\u4e86\u5f88\u597d\u7684\u4fc3\u8fdb\u4f5c\u7528\u3002\u6b64\u5916\uff0c\u5b66\u9662\u4e0e\u591a\u6240\u56fd\u5916\u5927\u5b66\u62e5\u6709\u5408\u4f5c\u534f\u8bae\u548c\u5bc6\u5207\u5173\u7cfb\uff0c\u5305\u62ec\u65e5\u672c\u4e1c\u5317\u5927\u5b66\u3001\u97e9\u56fd\u6c49\u9633\u5927\u5b66\u3001\u632a\u5a01\u79d1\u6280\u5927\u5b66\u3001\u4e39\u9ea6\u5965\u5c14\u5821\u5927\u5b66\u3001\u6fb3\u5927\u5229\u4e9a\u6089\u5c3c\u5927\u5b66\u3001\u6cd5\u56fd\u5df4\u9ece\u516d\u5927\u7b49\u3002\n","customFeature":{"boxColor":"rgb(0, 0, 0)","boxR":"5","boxStyle":false,"boxX":"0","boxY":"0"},"animations":[],"page_form":"","compId":"text1","parentCompid":"text1","markColor":"","mode":0},"has_tabbar":0,"page_hidden":true,"page_form":"","top_nav":{"navigationBarBackgroundColor":"#000000","navigationBarTextStyle":"white","navigationBarTitleText":"\u65b0\u9875\u9762"}},
    need_login: false,
    page_router: 'page10009',
    page_form: 'none',
      list_compids_params: [],
      user_center_compids_params: [],
      goods_compids_params: [],
  prevPage:0,
      tostoreComps: [],
      carouselGroupidsParams: [],
      relobj_auto: [],
      bbsCompIds: [],
      dynamicVesselComps: [],
      communityComps: [],
      franchiseeComps: [],
      cityLocationComps: [],
      seckillOnLoadCompidParam: [],
      dynamicClassifyGroupidsParams: [],
      videoListComps: [],
      videoProjectComps: [],
      returnToVersionFlag: true,
  requesting: false,
  requestNum: 1,
  modelChoose: [],
  modelChooseId: '',
  modelChooseName: [],
  onLoad: function (e) {
    app.onPageLoad(e);
  },
  dataInitial: function () {
    app.pageDataInitial();
  },
  onShareAppMessage: function (e) {
    return app.onPageShareAppMessage(e);
  },
  onShow: function () {
    app.onPageShow();
  },
  reachBottomFuc: [],
  onReachBottom: function () {
    app.onPageReachBottom( this.reachBottomFuc );
  },
  onUnload: function () {
    app.onPageUnload();
  },
  tapPrevewPictureHandler: function (e) {
    app.tapPrevewPictureHandler(e);
  },
  suspensionBottom: function () {
    app.suspensionBottom();
  },
  pageScrollFunc: function (e) {
    app.pageScrollFunc(e);
  },
  dynamicVesselScrollFunc: function (e) {
    app.dynamicVesselScrollFunc(e);
  },
  goodsScrollFunc: function (e) {
    app.goodsScrollFunc(e);
  },
  takeoutStyleScrollFunc: function(e){
    app.takeoutStyleScrollFunc(e);
  },
  franchiseeScrollFunc: function (e) {
    app.franchiseeScrollFunc(e);
  },
  seckillScrollFunc: function (e) {
    app.seckillScrollFunc(e);
  },
  videoScrollFunc: function (e) {
    app.videoScrollFunc(e);
  },
  carouselVideoClose: function(e) {
    app.carouselVideoClose(e);
  },
  changeCount: function (e) {
    app.changeCount(e);
  },
  inputChange: function (e) {
    app.inputChange(e);
  },
  bindDateChange: function (e) {
    app.bindDateChange(e);
  },
  bindTimeChange: function (e) {
    app.bindTimeChange(e);
  },
  bindSelectChange: function (e) {
    app.bindSelectChange(e);
  },
  bindScoreChange: function (e) {
    app.bindScoreChange(e);
  },
  submitForm: function (e) {
    app.submitForm(e);
  },
  udpateVideoSrc: function (e) {
    app.udpateVideoSrc(e);
  },
  tapMapDetail: function (e) {
    app.tapMapDetail(e);
  },
  uploadFormImg: function (e) {
    app.uploadFormImg(e);
  },
  deleteUploadImg: function (e) {
    app.deleteUploadImg(e);
  },
  listVesselTurnToPage: function (e) {
    app.listVesselTurnToPage(e);
  },
  dynamicVesselTurnToPage: function (e) {
    app.dynamicVesselTurnToPage(e);
  },
  userCenterTurnToPage: function (e) {
    app.userCenterTurnToPage(e);
  },
  turnToGoodsDetail: function (e) {
    app.turnToGoodsDetail(e);
  },
  turnToFranchiseeDetail: function (e) {
    app.turnToFranchiseeDetail(e);
  },
  turnToSeckillDetail: function (e) {
    app.turnToSeckillDetail(e);
  },
  sortListFunc: function (e) {
    app.sortListFunc(e);
  },
  bbsInputComment: function (e) {
    app.bbsInputComment(e);
  },
  bbsInputReply: function (e) {
    app.bbsInputReply(e);
  },
  uploadBbsCommentImage: function (e) {
    app.uploadBbsCommentImage(e);
  },
  uploadBbsReplyImage: function (e) {
    app.uploadBbsReplyImage(e);
  },
  deleteCommentImage: function (e) {
    app.deleteCommentImage(e);
  },
  deleteReplyImage: function (e) {
    app.deleteReplyImage(e);
  },
  bbsPublishComment: function (e) {
    app.bbsPublishComment(e);
  },
  clickBbsReplyBtn: function (e) {
    app.clickBbsReplyBtn(e);
  },
  bbsPublishReply: function (e) {
    app.bbsPublishReply(e);
  },
  searchList: function (e) {
    app.searchList(e);
  },
  selectLocal: function (e) {
    app.selectLocal(e);
  },
  cancelCity: function (e) {
    app.cancelCity(e);
  },
  bindCityChange: function (e) {
    app.bindCityChange(e);
  },
  submitCity: function (e) {
    app.submitCity(e);
  },
  openTakeoutLocation: function (e) {
    app.openTakeoutLocation(e);
  },
  callTakeout: function (e) {
    app.callTakeout(e);
  },
  getMoreAssess: function (e) {
    app.getMoreAssess(e);
  },
  changeEvaluate: function (e) {
    app.changeEvaluate(e)
  },
  deleteAllCarts: function (e) {
    app.deleteAllCarts(e);
  },
  clickCategory: function (e) {
    app.clickCategory(e);
  },
  goodsListMinus: function (e) {
    app.goodsListMinus(e);
  },
  goodsListPlus: function (e) {
    app.goodsListPlus(e);
  },
  cartListMinus: function (e) {
    app.cartListMinus(e);
  },
  cartListPlus: function (e) {
    app.cartListPlus(e);
  },
  changeAssessType: function (e) {
    app.changeAssessType(e);
  },
  showShoppingCartPop: function (e) {
    app.showShoppingCartPop(e);
  },
  hideShoppingCart: function (e) {
    app.hideShoppingCart(e);
  },
  showGoodsDetail: function (e) {
    app.showGoodsDetail(e);
  },
  hideDetailPop: function (e) {
    app.hideDetailPop(e);
  },
  hideModelPop: function (e) {
    app.hideModelPop(e);
  },
  chooseModel: function (e) {
    app.chooseModel(e);
  },
  sureChooseModel: function (e) {
    app.sureChooseModel(e);
  },
  clickChooseComplete: function (e) {
    app.clickChooseComplete(e);
  },
  reLocalAddress: function(e){
    app.reLocalAddress(e);
  },
  tapGoodsTradeHandler: function (e) {
    app.tapGoodsTradeHandler(e);
  },
  tapVideoHandler: function(e){
    app.tapVideoHandler(e);
  },
  tapVideoPlayHandler: function(e){
    app.tapVideoPlayHandler(e);  
  },
  tapVideoHandler: function(e){
    app.tapVideoHandler(e);
  },
  tapInnerLinkHandler: function (e) {
    app.tapInnerLinkHandler(e);
  },
  tapPhoneCallHandler: function (e) {
    app.tapPhoneCallHandler(e);
  },
  tapRefreshListHandler: function (e) {
    app.tapRefreshListHandler(e);
  },
  tapGetCouponHandler: function (e) {
    app.tapGetCouponHandler(e);
  },
  tapCommunityHandler: function (e) {
    app.tapCommunityHandler(e);
  },
  tapPageShareHandler:function(e) {
    app.tapPageShareHandler(e);
  },
  turnToCommunityPage: function (e) {
    app.turnToCommunityPage(e);
  },
  tapToFranchiseeHandler: function (e) {
    app.tapToFranchiseeHandler(e);
  },
  tapToTransferPageHandler: function () {
    app.tapToTransferPageHandler();
  },
  tapToSeckillHandler: function (e) {
    app.tapToSeckillHandler(e);
  },
  tapToPromotionHandler: function () {
    app.tapToPromotionHandler();
  },
  tapToCouponReceiveListHandler: function () {
    app.tapToCouponReceiveListHandler();
  },
  tapToRechargeHandler: function () {
    app.tapToRechargeHandler();
  },
  tapToXcx: function (e) {
    app.tapToXcx(e);
  },
  tapFranchiseeLocation: function (e) {
    app.tapFranchiseeLocation(e);
  },
  showAddShoppingcart: function (e) {
    app.showAddShoppingcart(e);
  },
  hideAddShoppingcart: function () {
    app.hideAddShoppingcart();
  },
  selectGoodsSubModel: function (e) {
    app.selectGoodsSubModel(e);
  },
  resetSelectCountPrice: function () {
    app.resetSelectCountPrice();
  },
  // 电商
  clickGoodsMinusButton: function (e) {
    app.clickGoodsMinusButton();
  },
  clickGoodsPlusButton: function (e) {
    app.clickGoodsPlusButton();
  },
  sureAddToShoppingCart: function () {
    app.sureAddToShoppingCart();
  },
  sureAddToBuyNow: function () {
    app.sureAddToBuyNow();
  },
  clickTostoreMinusButton: function (e) {
    app.clickTostoreMinusButton(e);
  },
  clickTostorePlusButton: function (e) {
    app.clickTostorePlusButton(e);
  },
  readyToPay: function () {
    app.readyToTostorePay();
  },
  getValidateTostore: function () {
    app.getValidateTostore();
  },
  goToShoppingCart: function () {
    app.goToShoppingCart();
  },
  getCartList: function () {
    app.getTostoreCartList();
  },
  stopPropagation: function () {
  },
  turnToSearchPage:function (e) {
    app.turnToSearchPage(e);
  },
  previewImage: function (e) {
    var dataset = e.currentTarget.dataset;
    app.previewImage({
      current : dataset.src,
      urls: dataset.previewImgarr,
    });
  },
  scrollPageTop: function () {
    app.pageScrollTo(0);
  },
  suspensionTurnToPage: function (e) {
    app.suspensionTurnToPage(e);
  },
   tapToLuckyWheel: function (e) {
    app.tapToLuckyWheel(e);
  },
  tapToGoldenEggs: function (e) {
    app.tapToGoldenEggs(e);
  },
  tapToScratchCard: function (e) {
    app.tapToScratchCard(e);
  },
  tapToLuckyWheel: function (e) {
    app.tapToLuckyWheel(e);
  },
  keywordList:{},
  bindSearchTextChange: function (e) {
    this.keywordList[e.currentTarget.dataset.compid] = e.detail.value;
  },
  // 文字组件跳到地图
  textToMap: function(e) {
    app.textToMap(e);
  },
  tapDynamicClassifyFunc: function(e){
    app.tapDynamicClassifyFunc(e);
  },
  // 跳转到视频详情
  turnToVideoDetail : function(e) {
    app.turnToVideoDetail(e);
  },
  // 单个视频组件播放视频
  startPlayVideo : function(e) {
    app.startPlayVideo(e);
  },
  // 视频播放报错
  videoError: function(e) {
    app.showModal({
      content: e.detail.errMsg
    });
  }
};
Page(pageData);
